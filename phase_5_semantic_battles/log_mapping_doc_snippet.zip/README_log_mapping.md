# Visual Mapping Philosophy

This app is grounded in the principle that musical intervals are best represented as simple ratios (e.g. 3/2 for a perfect fifth), not abstract logarithmic values.

Internally, the system calculates log₂(ratio) to render these intervals on a perceptually consistent visual line. This ensures that doubling in frequency (e.g. 200 Hz → 400 Hz) appears as a linear octave jump on screen — just as our ears perceive it.

However, users interact exclusively with integer ratios, preserving the intuitive harmonic clarity of traditional music theory.

→ In short: You think in ratios, the app displays in perception.
